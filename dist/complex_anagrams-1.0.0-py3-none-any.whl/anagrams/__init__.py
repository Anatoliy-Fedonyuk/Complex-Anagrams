from .anagrams import get_anagram

print('--this module init at anagrams--')
